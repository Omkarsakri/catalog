public class ShamirSecretSharing {
}
